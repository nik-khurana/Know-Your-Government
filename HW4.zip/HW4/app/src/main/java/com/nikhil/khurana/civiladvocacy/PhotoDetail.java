package com.nikhil.khurana.civiladvocacy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

public class PhotoDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_detail);
        String location=getIntent().getStringExtra("location");
        String office=getIntent().getStringExtra("office");
        String name=getIntent().getStringExtra("name");
        String image=getIntent().getStringExtra("image");
        String party=getIntent().getStringExtra("party");
        ConstraintLayout constraintLayout=findViewById(R.id.photo_detail_cl);
        TextView pdlocation=findViewById(R.id.photo_detail_location);
        TextView pdoffice=findViewById(R.id.photo_detail_office);
        TextView pdname=findViewById(R.id.photo_detail_name);
        ImageView pdimage=findViewById(R.id.photo_detail_photo);
        ImageView pdlogo=findViewById(R.id.photo_detail_party_logo);

        pdlocation.setText(location);
        pdoffice.setText(office);
        pdname.setText(name);
        Picasso picasso = null;
        picasso = Picasso.get();
        picasso.setLoggingEnabled(false);

        picasso.load(image)
                .error(R.drawable.brokenimage)
                .placeholder(R.drawable.placeholder)
                .memoryPolicy(MemoryPolicy.NO_CACHE)
                .into(pdimage);

        if(party.equalsIgnoreCase("democratic party")){
            constraintLayout.setBackgroundColor(Color.BLUE);
            pdlogo.setImageDrawable(getResources().getDrawable(R.drawable.dem_logo));

        }else if(party.equalsIgnoreCase("republican party")){
            constraintLayout.setBackgroundColor(Color.RED);
            pdlogo.setImageDrawable(getResources().getDrawable(R.drawable.rep_logo));

        }else{
            constraintLayout.setBackgroundColor(Color.BLACK);
            pdlogo.setVisibility(View.INVISIBLE);

        }
        if(party.equalsIgnoreCase("democratic party")){
            //constraintLayout.setBackgroundColor(Color.BLUE);
            pdlogo.setImageDrawable(getResources().getDrawable(R.drawable.dem_logo));
            pdlogo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://democrats.org/")));
                }
            });

        }else if(party.equalsIgnoreCase("republican party")){
            //constraintLayout.setBackgroundColor(Color.RED);
            pdlogo.setImageDrawable(getResources().getDrawable(R.drawable.rep_logo));
            pdlogo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://gop.com/")));
                }
            });

        }else{
            //cl.setBackgroundColor(Color.BLACK);
            //partylogo.setVisibility(View.INVISIBLE);

        }

    }
}