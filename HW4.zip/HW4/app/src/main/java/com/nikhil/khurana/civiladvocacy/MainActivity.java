package com.nikhil.khurana.civiladvocacy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    FusedLocationProviderClient mFusedLocationClient;
    int LOCATION_REQUEST =111;
    List<Representative> mainList=new ArrayList<>();
    MainAdapter mainAdapter;
    String loc="";
    RecyclerView recyclerView;
    static TextView main_location;

    public void setLocation(String address) {
        if(address.length()<loc.length()){
            main_location.setText(loc);

        }
        else {
            main_location.setText(address);
            loc = address;
        }

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putString("LOCATION_NAME",loc);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        loc=savedInstanceState.getString("LOCATION_NAME");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(loc.length()>0){
            MainRecyclerVolleyLoader.getSourceData(this,loc);

        }else{
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            determineLocation();
          }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        main_location = findViewById(R.id.main_location);
        recyclerView = findViewById(R.id.main_recylerview);

        mainAdapter = new MainAdapter(MainActivity.this, mainList);
        recyclerView.setAdapter(mainAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false));

        if(!doNetCheck()){
            main_location.setText("No Internet Access");
            Toast.makeText(this,"No Internet Access",Toast.LENGTH_LONG).show();
            showNoNetworkDialog();
            return;
        }


    }



    @SuppressLint("NewApi")
    private boolean doNetCheck() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

        return isConnected;
    }

    public void updateMainRecyclerData(ArrayList<Representative> mainArrayList) {

        mainList.clear();
        mainList.addAll(mainArrayList);
        mainAdapter.notifyItemRangeChanged(0, mainList.size());
        for (int i=0;i<mainArrayList.size();i++){
            System.out.println(i+"Fetched Office: "+mainArrayList.get(i).getOffice());
        }


    }

    @SuppressLint("MissingPermission")
    private void determineLocation() {
        main_location.setText("Location Not Available, Try Turning on Location or Search");
        //showNoLocationDialog();
        mainList.clear();
        if(!doNetCheck()){
            main_location.setText("No Internet Access");
            Toast.makeText(this,"No Internet Access",Toast.LENGTH_LONG).show();
            showNoNetworkDialog();
            return;


        }
        //mainAdapter.notifyItemRangeChanged(0,mainList.size());
        if (checkAppPermissions()) {
            mFusedLocationClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {
                        mainList.clear();
                        loc = getPlace(location);
                        main_location.setText(loc);
                        MainRecyclerVolleyLoader.getSourceData(MainActivity.this, loc);
                    }
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.info_activity){
            startActivity(new Intent(this,AboutActivity.class));
        }
        if(item.getItemId()==R.id.main_search){
            AlertDialog.Builder builder=new AlertDialog.Builder(this);
            EditText et = new EditText(this);
            et.setInputType(InputType.TYPE_CLASS_TEXT);
            et.setGravity(Gravity.CENTER_HORIZONTAL);
            builder.setView(et);

            builder.setPositiveButton("Search", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    String str=et.getText().toString();
                    if (str.length()>0) {
                        try {
                            if(!doNetCheck()){
                                main_location.setText("No Internet Access");
                                Toast.makeText(MainActivity.this,"No Internet Access",Toast.LENGTH_LONG).show();
                                doNetCheck();
                                return;

                            }
                            mainList.clear();
                            MainRecyclerVolleyLoader.getSourceData(MainActivity.this, str);
                            mainAdapter = new MainAdapter(MainActivity.this, mainList);
                            recyclerView.setAdapter(mainAdapter);
                            recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false));
                            main_location.setText(str);
                            loc=str;
                        } catch (Exception e) {
                            e.printStackTrace();

                        }
                    }
                    else
                        Toast.makeText(MainActivity.this,"Nothing Entered",Toast.LENGTH_LONG).show();
                }
            });
            // lambda can be used here (as is below)
            builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    Toast.makeText(MainActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                    return;
                }
            });
            builder.setTitle("Enter Address");

            AlertDialog dialog = builder.create();
            dialog.show();
        }
        return true;
    }

    private boolean checkAppPermissions() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    }, LOCATION_REQUEST);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST) {
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    determineLocation();
                } else {
                    main_location.setText("Location Not Available");
                    showNoLocationDialog();
                }
            }
        }
    }

    private String getPlace(Location loc) {

        StringBuilder sb = new StringBuilder();

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;

        try {
            addresses = geocoder.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
            String address=addresses.get(0).getAddressLine(0);
            sb.append(String.format(Locale.getDefault(), "%s", address));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    @Override
    public void onClick(View view) {
        int pos = recyclerView.getChildLayoutPosition(view);
        Representative rep =mainList.get(pos);

        Intent i = new Intent(this, OfficialActivity.class);
        i.putExtra("representative", rep);
        i.putExtra("current_location", loc);

        startActivity(i);


    }
    public void showNoNetworkDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("No Network Connection");
        builder.setMessage("Data cannot be accessed / loaded without an internet connection");
        builder.create().show();
    }

    public void showNoLocationDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("No Location Data");
        builder.setMessage("Current Location Not Available, Try Turning on Location and Try again or Search");
        builder.create().show();
    }

    public void eroor() {
        main_location.setText("Address Doesnt Exist\n Search Again or Open app again");
        mainList.clear();
        mainAdapter.notifyItemRangeChanged(0,mainList.size());
    }
}