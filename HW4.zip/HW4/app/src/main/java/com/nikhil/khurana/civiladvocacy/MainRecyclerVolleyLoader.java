package com.nikhil.khurana.civiladvocacy;

import android.net.Uri;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainRecyclerVolleyLoader {
    private static final String BASE_URL = "https://www.googleapis.com/civicinfo/v2/representatives";
    private static final String API_KEY = "AIzaSyDo4SaNvQ4nsjMCoCvoUWrVxGU19di60Ck";
   // String location="";
    public static void getSourceData(MainActivity mainActivity, String add) {
        RequestQueue queue = Volley.newRequestQueue(mainActivity);
        Uri.Builder buildURL = Uri.parse(BASE_URL).buildUpon();
        buildURL.appendQueryParameter("key", API_KEY);
        buildURL.appendQueryParameter("address", add);
        String urlToUse = buildURL.build().toString();
        Response.Listener<JSONObject> listener = response -> handleresults(mainActivity,response.toString());
        Response.ErrorListener error = error1 -> handleresults(mainActivity,error1.toString());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, urlToUse, null, listener, error);
        queue.add(jsonObjectRequest);
    }
    private static void handleresults(MainActivity mainActivity, String s) {
        System.out.println("Errrorrrr"+s);
        final ArrayList<Representative> mainArrayList = parseJSON(s);
        if(s.equalsIgnoreCase("com.android.volley.ClientError")){
            mainActivity.eroor();
        }
        if (mainArrayList != null)
            mainActivity.updateMainRecyclerData(mainArrayList);
        JSONObject baseObject = null;
        try {
            baseObject = new JSONObject(s);

        JSONObject normalizedAddress = baseObject.getJSONObject("normalizedInput");
            String address = "";
            address=normalizedAddress.getString("city") + ", " + normalizedAddress.getString("state") + " " + normalizedAddress.getString("zip");
            mainActivity.setLocation(address);

        } catch (Exception e){

        }


    }

    private static ArrayList<Representative> parseJSON(String jsonString) {
        ArrayList<Representative> mainArrayList = new ArrayList();
        try {
            JSONObject baseObject = new JSONObject(jsonString);
            JSONObject normalizedAddress = baseObject.getJSONObject("normalizedInput");

            JSONArray offices = baseObject.getJSONArray("offices");
            JSONArray officials = baseObject.getJSONArray("officials");
            String name="",office_name="",party="",add="",phone="",website="",email="",fb="",yt="",twit="",purl="";
            for (int i = 0; i < offices.length(); i++) {
                JSONObject office = offices.getJSONObject(i);
                office_name = office.getString("name");

                JSONArray official_indexes = office.getJSONArray("officialIndices");
                for (int j = 0; j < official_indexes.length(); j++) {
                    int index = official_indexes.getInt(j);

                    JSONObject official = officials.getJSONObject(index);
                    name=official.getString("name");
                    party=official.getString("party");


                    if(official.has("address")) {
                        JSONObject onlineaddress = official.getJSONArray("address").getJSONObject(0);
                        add=(buildAddressString(onlineaddress));
                    }
                    if (official.has("phones")) {
                        phone = official.getJSONArray("phones").getString(0);
                    }
                    if(official.has("urls")) {
                        website=official.getJSONArray("urls").getString(0);
                    }
                    if(official.has("emails")) {
                        email=official.getJSONArray("emails").getString(0);
                    }
                    if(official.has("photoUrl")) {
                        //String s=null;

                        purl=official.getString("photoUrl");
                        //purl="https://"+ s.split("//")[1];

                    }
                    if(official.has("channels")) {
                        JSONArray channels = official.getJSONArray("channels");
                        for (int k = 0; k < channels.length(); k++) {
                            JSONObject channel = channels.getJSONObject(k);
                            switch (channel.getString("type")) {
                                case "Facebook":
                                    fb=channel.getString("id");
                                    break;
                                case "Twitter":
                                    twit=channel.getString("id");
                                    break;
                                case "YouTube":
                                    yt=channel.getString("id");
                                    break;
                            }
                        }
                    }
                    mainArrayList.add(new Representative(name,office_name,party,add,phone,website,email,fb,yt,twit,purl));
                    add="";phone="";website="";email="";fb="";yt="";twit="";purl="";

                }

            }
        }catch (Exception e){
            e.printStackTrace();
        }


        return mainArrayList;




    }

    private static String buildAddressString(JSONObject address) throws JSONException {
        StringBuilder sb = new StringBuilder();
        if(address.has("line1")) {
            sb.append(address.getString("line1"));
            sb.append(", ");
        }

        if(address.has("line2")) {
            sb.append(address.getString("line2"));
            sb.append(", ");
        }

        if(address.has("line3")) {
            sb.append(address.getString("line3"));
            sb.append(", ");
        }

        sb.append(address.getString("city"));
        sb.append(", ");
        sb.append(address.getString("state"));
        sb.append(" ");
        sb.append(address.getString("zip"));

        return sb.toString();
    }
    }
