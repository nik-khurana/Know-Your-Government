package com.nikhil.khurana.civiladvocacy;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class MainViewHolder extends RecyclerView.ViewHolder {
    TextView office,namenparty;
    ImageView seperator;
    public MainViewHolder(View itemView) {
        super(itemView);
        office=itemView.findViewById(R.id.main_office_recycler);
        namenparty=itemView.findViewById(R.id.main_name_party_recycler);
        seperator=itemView.findViewById(R.id.main_seperator_recycler);
    }
}
