package com.nikhil.khurana.civiladvocacy;

import static com.nikhil.khurana.civiladvocacy.R.drawable.separator;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.transition.Hold;

import java.util.ArrayList;
import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainViewHolder> {

    MainActivity mainActivity;
    List<Representative> list;

    public MainAdapter(MainActivity mainActivity, List<Representative> mainList) {
        this.list=mainList;
        this.mainActivity=mainActivity;
    }

    @NonNull
    @Override
    public MainViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.main_recyclerview, parent, false);
        itemView.setOnClickListener(mainActivity);
        return new MainViewHolder(itemView);
    }

    @SuppressLint("ResourceType")
    @Override
    public void onBindViewHolder(@NonNull MainViewHolder holder, int position) {
        Representative representative=list.get(position);
        holder.office.setText(representative.getOffice());
        holder.namenparty.setText(representative.getName()+" ("+representative.getParty()+")");
        holder.seperator.setId(separator);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
