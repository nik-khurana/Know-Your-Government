package com.nikhil.khurana.civiladvocacy;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class OfficialActivity extends AppCompatActivity {

    TextView loc,name,office,add,phone,website,email,partydesc;
    String latitude="",longitude="";
    TextView addlabel,phonelabel,websitelabel,emaillabel;
    ConstraintLayout cl;
    ImageView img,partylogo,fb,yt,twit;

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putString("website",website.getText().toString());
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        website.setText(savedInstanceState.getString("website"));
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official);
        Representative representative = (Representative) getIntent().getSerializableExtra("representative");
        String location = getIntent().getStringExtra("current_location");
        addlabel=findViewById(R.id.address_label);
        phonelabel=findViewById(R.id.phone_label);
        emaillabel=findViewById(R.id.email_label);
        websitelabel=findViewById(R.id.website_label);
        addlabel.setVisibility(View.VISIBLE);
        phonelabel.setVisibility(View.VISIBLE);
        websitelabel.setVisibility(View.VISIBLE);
        emaillabel.setVisibility(View.VISIBLE);
        cl=findViewById(R.id.officail_activity_cl);
        loc=findViewById(R.id.current_location);
        loc.setText(location);
        name=findViewById(R.id.name_text_view);
        name.setText(representative.getName());
        office=findViewById(R.id.office_text_view);
        office.setText(representative.getOffice());
        add=findViewById(R.id.address_text_view);
        add.setText(representative.getAddress());
        add.setVisibility(View.VISIBLE);
        if(add.getText().toString().length()==0){
            add.setVisibility(View.GONE);
            addlabel.setVisibility(View.GONE);
        }
        partydesc=findViewById(R.id.party_text_view);
        partydesc.setText(representative.getParty());
        //Linkify.addLinks(add, Linkify.ALL);
        Pattern pattern = Pattern.compile(".*", Pattern.DOTALL);
        Linkify.addLinks(add, pattern, "geo:0,0?q=");
        add.setLinkTextColor(Color.WHITE);

        phone=findViewById(R.id.phone_text_view);
        phone.setText(representative.getPhone());
        phone.setVisibility(View.VISIBLE);
        phone.setLinkTextColor(Color.WHITE);
        Linkify.addLinks(phone, Linkify.ALL);
       // addlabel.findViewById(R.id.address_label);
        if(phone.getText().toString().length()==0){
            phone.setVisibility(View.GONE);
            phonelabel.setVisibility(View.GONE);
        }
        website=findViewById(R.id.website_text_view);
        website.setText(representative.getWebsite());
        website.setVisibility(View.VISIBLE);
        website.setLinkTextColor(Color.WHITE);
        Linkify.addLinks(website, Linkify.ALL);
        if(website.getText().toString().length()==0){
            website.setVisibility(View.GONE);
            websitelabel.setVisibility(View.GONE);
        }
        email=findViewById(R.id.email_text_view);
        email.setText(representative.getEmail());
        email.setVisibility(View.VISIBLE);
        email.setLinkTextColor(Color.WHITE);
        Linkify.addLinks(email, Linkify.ALL);
        if(email.getText().toString().length()==0){
            email.setVisibility(View.GONE);
            emaillabel.setVisibility(View.GONE);
        }
        img=findViewById(R.id.official_photo);
        partylogo=findViewById(R.id.party_logo);
        fb=findViewById(R.id.facebook_logo);
        fb.setVisibility(View.VISIBLE);
        if(representative.getFacebook().length()==0) {
            fb.setVisibility(View.GONE);
        }else{
            fb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String FACEBOOK_URL = "https://www.facebook.com/" + representative.getFacebook();
                    String urlToUse;
                    PackageManager packageManager = getPackageManager();
                    try {
                        int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
                        if (versionCode >= 3002850) { //newer versions of fb app
                            urlToUse = "fb://facewebmodal/f?href=" + FACEBOOK_URL;
                        } else { //older versions of fb app
                            urlToUse = "fb://page/" + representative.getFacebook();
                        }
                    } catch (PackageManager.NameNotFoundException e) {
                        urlToUse = FACEBOOK_URL; //normal web url
                    }
                    Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
                    facebookIntent.setData(Uri.parse(urlToUse));
                    startActivity(facebookIntent);
                }
            });
        }
        yt=findViewById(R.id.youtube_logo);
        yt.setVisibility(View.VISIBLE);
        if(representative.getYoutube().length()==0){
            yt.setVisibility(View.GONE);
        }else{
            yt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String name = representative.getYoutube();
                    Intent intent = null;
                    try {
                        intent = new Intent(Intent.ACTION_VIEW);
                        intent.setPackage("com.google.android.youtube");
                        intent.setData(Uri.parse("https://www.youtube.com/" + name));
                        startActivity(intent);
                    } catch (ActivityNotFoundException e) {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://www.youtube.com/" + name)));
                    }
                }
            });
        }

        twit=findViewById(R.id.twitter_logo);
        twit.setVisibility(View.VISIBLE);
        if(representative.getTwitter().length()==0){
            twit.setVisibility(View.GONE);
        }else{
            twit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = null;
                    String name = representative.getTwitter();
                    try {
                        // get the Twitter app if possible
                        getPackageManager().getPackageInfo("com.twitter.android", 0);
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + name));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    } catch (Exception e) {
                        // no Twitter app, revert to browser
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/" + name));
                    }
                    startActivity(intent);
                }
            });
        }


        if(representative.getParty().equalsIgnoreCase("democratic party")){
            cl.setBackgroundColor(Color.BLUE);
            partylogo.setImageDrawable(getResources().getDrawable(R.drawable.dem_logo));
            partylogo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://democrats.org/")));
                }
            });

        }else if(representative.getParty().equalsIgnoreCase("republican party")){
            cl.setBackgroundColor(Color.RED);
            partylogo.setImageDrawable(getResources().getDrawable(R.drawable.rep_logo));
            partylogo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://gop.com/")));
                }
            });

        }else{
            cl.setBackgroundColor(Color.BLACK);
            partylogo.setVisibility(View.INVISIBLE);

        }
//        fb.setImageResource(R.drawable.facebook);
  //      yt.setImageResource(R.drawable.youtube);
    //    twit.setImageResource(R.drawable.twitter);
        String imge=representative.getPhotoUrl();
        if(imge.length()>0) {

            imge="https://"+imge.split("//")[1];
            Picasso picasso = null;
            picasso = Picasso.get();
            picasso.setLoggingEnabled(false);
            picasso.load(imge)
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.placeholder)
                    .memoryPolicy(MemoryPolicy.NO_CACHE)
                    .into(img);
            String finalImge = imge;
            img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent;
                    intent = new Intent(OfficialActivity.this,PhotoDetail.class);
                    intent.putExtra("location",loc.getText().toString());
                    intent.putExtra("office",representative.getOffice());
                    intent.putExtra("name",representative.getName());
                    intent.putExtra("image", finalImge);
                    intent.putExtra("party",representative.getParty());

                    startActivity(intent);
                }
            });
        }
        else{
            img.setImageDrawable(getResources().getDrawable(R.drawable.missing));
        }

    }
}